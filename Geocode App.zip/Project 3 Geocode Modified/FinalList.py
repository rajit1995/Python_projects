

list1 = tlist 


myData = [
[42.43472,-83.985, 'Hell, MI 48169, USA']
];
